<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="com.kh.mvc.model.MemberDTO"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>회원 정보 수정</title>
</head>
<body>
	<h1>회원 정보 수정</h1>
	<%
	MemberDTO m = (MemberDTO) request.getAttribute("member");
	if (m != null) {
	%>
	<!-- 실제 수정 데이터를 서블릿으로 전송하는 폼 -->
	<form action="${pageContext.request.contextPath}/member/update"
		method="post">
		<!-- 고유 ID는 숨겨서 전송 -->
		<input type="hidden" name="id" value="<%=m.getId()%>">

		<p>
			<strong>회원 번호:</strong>
			<%=m.getId()%></p>

		<p>
			<label>이름: </label> <input type="text" name="name"
				value="<%=m.getName()%>" required>
		</p>

		<p>
			<label>이메일: </label> <input type="email" name="email"
				value="<%=m.getEmail()%>" required>
		</p>

		<p>
			<label>나이: </label> <input type="number" name="age"
				value="<%=m.getAge()%>" required>
		</p>

		<hr>
		<button type="submit">수정 완료</button>
		<button type="button"
			onclick="location.href='${pageContext.request.contextPath}/member/list'">취소</button>
	</form>
	<%
	} else {
	%>
	<p style="color: red;">회원 정보를 불러오지 못했습니다. 올바른 접근이 아닙니다.</p>
	<button type="button"
		onclick="location.href='${pageContext.request.contextPath}/member/list'">목록으로
		돌아가기</button>
	<%
	}
	%>
</body>
</html>

</body>
</html>
