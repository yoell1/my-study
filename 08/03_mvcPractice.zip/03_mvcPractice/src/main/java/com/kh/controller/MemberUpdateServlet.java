package com.kh.controller;

import java.io.IOException;
import com.kh.mvc.model.MemberDAO;
import com.kh.mvc.model.MemberDTO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/member/update")
public class MemberUpdateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // 수정 폼 화면 열기 (GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        
        MemberDAO dao = new MemberDAO();
        MemberDTO member = dao.findById(id);
        
        request.setAttribute("member", member);
        request.getRequestDispatcher("/WEB-INF/views/member/update.jsp").forward(request, response);
    }

    // 실제 데이터베이스 수정 실행 (POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        int age = Integer.parseInt(request.getParameter("age"));
        
        MemberDTO member = new MemberDTO(id, name, email, age);
        
        MemberDAO dao = new MemberDAO();
        int result = dao.update(member);
        
        if (result > 0) {
            response.sendRedirect(request.getContextPath() + "/member/list");
        }
    }
}
