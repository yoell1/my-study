package com.kh.controller;

import java.io.IOException;
import com.kh.mvc.model.MemberDAO; 
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/member/delete")
public class MemberDeleteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // list.jsp에서 보낸 ?id=회원번호 파라미터 추출
        int id = Integer.parseInt(request.getParameter("id"));

        // 서블릿단은 주소 제어, 실제 DB 접속과 삭제 처리는 MemberDAO
        MemberDAO dao = new MemberDAO();
        dao.delete(id); 
        
        // 삭제 완료 후 회원 목록 페이지로 리다이렉트 이동
        response.sendRedirect(request.getContextPath() + "/member/list");
    }
}
