package com.kh.community;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.security.autoconfigure.UserDetailsServiceAutoConfiguration;

@SpringBootApplication(exclude = UserDetailsServiceAutoConfiguration.class)// <-() 안에 내용 이 로그인 자동설정을 뺀다는 얘기임
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
