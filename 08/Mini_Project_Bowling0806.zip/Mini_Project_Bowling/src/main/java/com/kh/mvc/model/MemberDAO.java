package com.kh.mvc.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class MemberDAO {

	// 1. 신규 회원 등록 (INSERT)
	public int insertMember(Connection conn, MemberDTO member) {
		int result = 0;
		String sql = "INSERT INTO BOWLER (BOWLER_ID, NAME, LANE_NUMBER, GAME_COUNT, GRADE, STATUS) VALUES (SEQ_BOWLER_ID.NEXTVAL, ?, ?, ?, ?, 'Y')";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, member.getName());
			pstmt.setInt(2, member.getLaneNumber());
			pstmt.setInt(3, member.getGameCount());
			pstmt.setString(4, member.getGrade());

			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	// 2. 전체 회원 목록 조회 (SELECT) - 이용 중('Y')인 회원만 화면에 조회
	public ArrayList<MemberDTO> selectAllMembers(Connection conn) {
		ArrayList<MemberDTO> list = new ArrayList<>();
		String sql = "SELECT * FROM BOWLER WHERE STATUS = 'Y' ORDER BY BOWLER_ID DESC";

		try (PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rset = pstmt.executeQuery()) {

			while (rset.next()) {
				MemberDTO m = new MemberDTO(rset.getInt("BOWLER_ID"), rset.getString("NAME"),
						rset.getInt("LANE_NUMBER"), rset.getInt("GAME_COUNT"), rset.getString("GRADE"));
				list.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	// 3. 회원 퇴실 처리 (STATUS 상태값을 'N'으로 변경)
	public int deleteMember(Connection conn, int bowlerId) {
		int result = 0;
		String sql = "UPDATE BOWLER SET STATUS = 'N' WHERE BOWLER_ID = ?";

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, bowlerId);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	// 4. 퇴실 결제 정산 (INSERT INTO BILLING)
	public int insertBilling(Connection conn, int bowlerId, String grade, int gameCount) {
		int result = 0;
		String sql = "INSERT INTO BILLING (BILLING_ID, BOWLER_ID, TOTAL_FEE, PAYMENT_DATE) VALUES (SEQ_BILLING_ID.NEXTVAL, ?, ?, SYSDATE)";

		int feePerGame = "VIP".equals(grade) ? 4000 : 5000;
		int totalFee = gameCount * feePerGame;

		try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, bowlerId);
			pstmt.setInt(2, totalFee);

			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	// 5. 총 누적 매출 및 총 결제 건수 통계 조회
	public int[] selectSalesSummary(Connection conn) {
		int[] summary = new int[2];
		String sql = "SELECT COUNT(BILLING_ID), NVL(SUM(TOTAL_FEE), 0) FROM BILLING";

		try (PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rset = pstmt.executeQuery()) {
			if (rset.next()) {
				summary[0] = rset.getInt(1);
				summary[1] = rset.getInt(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return summary;
	}

	// 6. 전체 정산/결제 이력 상세 목록 조회
	public ArrayList<HashMap<String, Object>> selectBillingList(Connection conn) {
		ArrayList<HashMap<String, Object>> list = new ArrayList<>();
		String sql = "SELECT BILLING_ID, BOWLER_ID, TOTAL_FEE, TO_CHAR(PAYMENT_DATE, 'YYYY-MM-DD HH24:MI:SS') AS P_DATE FROM BILLING ORDER BY BILLING_ID DESC";

		try (PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rset = pstmt.executeQuery()) {

			while (rset.next()) {
				HashMap<String, Object> map = new HashMap<>();
				map.put("billingId", rset.getInt("BILLING_ID"));
				map.put("bowlerId", rset.getInt("BOWLER_ID"));
				map.put("totalFee", rset.getInt("TOTAL_FEE"));
				map.put("paymentDate", rset.getString("P_DATE"));
				list.add(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
    // 7. 개발자/관리자 수동 테이블 초기화 (데이터 없는 깨끗한 빈 상태로 생성)
    public boolean resetAndInsertSampleData(Connection conn) { // 메소드명은 기존 연결을 위해 유지합니다.
        boolean isSuccess = false;
        
        // 기존 DB 개체 삭제 쿼리
        String dropBillingTable = "DROP TABLE BILLING CASCADE CONSTRAINTS";
        String dropBowlerTable = "DROP TABLE BOWLER CASCADE CONSTRAINTS";
        String dropBillingSeq = "DROP SEQUENCE SEQ_BILLING_ID";
        String dropBowlerSeq = "DROP SEQUENCE SEQ_BOWLER_ID";
        
        // 깨끗한 새 시퀀스 생성 쿼리 (1번부터 깔끔하게 시작)
		String createBowlerSeq = "CREATE SEQUENCE SEQ_BOWLER_ID START WITH 1 INCREMENT BY 1 NOCACHE";
        String createBillingSeq = "CREATE SEQUENCE SEQ_BILLING_ID START WITH 1 INCREMENT BY 1 NOCACHE";
        
        // 깨끗한 새 테이블 생성 쿼리
        String createBowlerTable = "CREATE TABLE BOWLER ("
                + "BOWLER_ID NUMBER PRIMARY KEY, "
                + "NAME VARCHAR2(50) NOT NULL, "
                + "LANE_NUMBER NUMBER NOT NULL, "
                + "GAME_COUNT NUMBER DEFAULT 0, "
                + "GRADE VARCHAR2(20) DEFAULT '일반', "
                + "STATUS VARCHAR2(2) DEFAULT 'Y'"
                + ")";
                
        String createBillingTable = "CREATE TABLE BILLING ("
                + "BILLING_ID NUMBER PRIMARY KEY, "
                + "BOWLER_ID NUMBER NOT NULL, "
                + "TOTAL_FEE NUMBER NOT NULL, "
                + "PAYMENT_DATE DATE DEFAULT SYSDATE"
                + ")";

        try (java.sql.Statement stmt = conn.createStatement()) {
            
            // 1. 기존에 쌓여있던 쓰레기 데이터 및 테이블 완전 삭제
            try { stmt.executeUpdate(dropBillingTable); } catch (Exception e) {}
            try { stmt.executeUpdate(dropBowlerTable); } catch (Exception e) {}
            try { stmt.executeUpdate(dropBillingSeq); } catch (Exception e) {}
            try { stmt.executeUpdate(dropBowlerSeq); } catch (Exception e) {}
            
            // 2. 데이터가 전혀 없는 완전히 빈 테이블과 시퀀스 재생성
            stmt.executeUpdate(createBowlerSeq);
            stmt.executeUpdate(createBillingSeq);
            stmt.executeUpdate(createBowlerTable);
            stmt.executeUpdate(createBillingTable);
            
            System.out.println("[DAO 로그] DB 가 깔끔하게 빈 상태로 초기화되었습니다.");
            isSuccess = true;
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return isSuccess;
    }

}
