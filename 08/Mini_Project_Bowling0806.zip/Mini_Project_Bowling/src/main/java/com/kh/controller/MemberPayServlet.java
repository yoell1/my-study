package com.kh.controller;

import java.io.IOException;
import java.io.PrintWriter;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/mvc/member/pay")
public class MemberPayServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private MemberService memberService = new MemberService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        int bowlerId = Integer.parseInt(request.getParameter("bowlerId"));
        String grade = request.getParameter("grade");
        int gameCount = Integer.parseInt(request.getParameter("gameCount"));

        if (gameCount == 0) {
            out.print("<script>alert('이용 내역(게임 수)이 없어 정산할 수 없습니다.'); history.back();</script>");
            return;
        }

        int result = memberService.processPaymentAndCheckOut(bowlerId, grade, gameCount);

        if (result == 1) {
            int fee = "VIP".equals(grade) ? 4000 : 5000;
            int total = gameCount * fee;
            out.print("<script>alert('[' + " + bowlerId + " + \"번 회원] 총 \" + " + total + " + \"원 결제가 완료되었습니다. 퇴실 처리됩니다.\"); location.href='" + request.getContextPath() + "/mvc/member/list';</script>");
        } else if (result == -1) {
            out.print("<script>alert('퇴실 상태 변경에 실패하여 결제가 취소되었습니다.'); history.back();</script>");
        } else if (result == 0) {
            out.print("<script>alert('정산 기록 등록에 실패했습니다.'); history.back();</script>");
        } else {
            out.print("<script>alert('데이터베이스 처리 중 치명적인 오류가 발생했습니다.'); history.back();</script>");
        }
    }
}
