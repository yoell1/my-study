package com.kh.mvc.model;

public class MemberDTO {
	private int bowlerId;
	private String name;
	private int laneNumber;
	private int gameCount;
	private String grade;

	// 기본 생성자
	public MemberDTO() {
	}

	// 매개변수 있는 생성자
	public MemberDTO(int bowlerId, String name, int laneNumber, int gameCount, String grade) {
		this.bowlerId = bowlerId;
		this.name = name;
		this.laneNumber = laneNumber;
		this.gameCount = gameCount;
		this.grade = grade;
	}

	// Getter / Setter
	public int getBowlerId() {
		return bowlerId;
	}

	public void setBowlerId(int bowlerId) {
		this.bowlerId = bowlerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLaneNumber() {
		return laneNumber;
	}

	public void setLaneNumber(int laneNumber) {
		this.laneNumber = laneNumber;
	}

	public int getGameCount() {
		return gameCount;
	}

	public void setGameCount(int gameCount) {
		this.gameCount = gameCount;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}
}
