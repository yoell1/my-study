package com.kh.mvc.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.kh.mvc.model.MemberDAO;
import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.util.DBUtil;

public class MemberService {
	private MemberDAO memberDao = new MemberDAO();

	// 1. SalesReportServlet 관련 로직
	public int[] getSalesSummary() {
		try (Connection conn = DBUtil.getConnection()) {
			return memberDao.selectSalesSummary(conn);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<HashMap<String, Object>> getBillingList() {
		try (Connection conn = DBUtil.getConnection()) {
			return memberDao.selectBillingList(conn);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// 2. MemberListServlet 관련 로직
	public ArrayList<MemberDTO> selectAllMembers() {
		try (Connection conn = DBUtil.getConnection()) {
			return memberDao.selectAllMembers(conn);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	// 3. MemberInsertServlet 관련 로직
	public int insertMember(MemberDTO member) {
		try (Connection conn = DBUtil.getConnection()) {
			return memberDao.insertMember(conn, member);
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}

	// 4. MemberDeleteServlet 관련 로직
	public int deleteMemberDirect(int bowlerId) {
		try (Connection conn = DBUtil.getConnection()) {
			return memberDao.deleteMember(conn, bowlerId);
		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}

	// 5. MemberPayServlet 관련 로직 (트랜잭션 처리)
	public int processPaymentAndCheckOut(int bowlerId, String grade, int gameCount) {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			conn.setAutoCommit(false);

			int insertResult = memberDao.insertBilling(conn, bowlerId, grade, gameCount);

			if (insertResult > 0) {
				int deleteResult = memberDao.deleteMember(conn, bowlerId);

				if (deleteResult > 0) {
					conn.commit();
					return 1;
				} else {
					conn.rollback();
					return -1;
				}
			} else {
				conn.rollback();
				return 0;
			}
		} catch (SQLException e) {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}
			e.printStackTrace();
			return -2;
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// MemberService 클래스 내부에 추가할 메소드
	// 여기서부터 메소드 끝까지 그대로 복사해서 덮어쓰세요!
	public void initializeDatabase() {
		java.sql.Connection conn = null;

		try {
			// 1. try 블록 안에서 안전하게 커넥션을 획득합니다. (예외 처리 해결)
			conn = com.kh.mvc.util.DBUtil.getConnection();

			// 수동 트랜잭션을 위해 오토 커밋을 끕니다.
			conn.setAutoCommit(false);

			// 2. DAO의 초기화 로직을 호출합니다.
			boolean success = memberDao.resetAndInsertSampleData(conn);

			// 3. 성공 여부에 따른 트랜잭션 확정/취소 처리
			if (success) {
				conn.commit();
				System.out.println("[서비스 로그] DB 초기화 트랜잭션 커밋 완료!");
			} else {
				conn.rollback();
				System.out.println("[서비스 로그] DB 초기화 실패로 인한 롤백 수행.");
			}

		} catch (java.sql.SQLException e) {
			try {
				if (conn != null)
					conn.rollback();
			} catch (Exception ex) {
			}
			e.printStackTrace();
		} finally {
			// 사용이 끝난 커넥션을 안전하게 닫아줍니다.
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
			}
		}
	}

}
