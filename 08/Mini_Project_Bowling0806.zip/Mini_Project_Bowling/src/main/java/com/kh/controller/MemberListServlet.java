package com.kh.controller;

import java.io.IOException;
import java.util.ArrayList;

import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/mvc/member/list")
public class MemberListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<MemberDTO> list = memberService.selectAllMembers();

		request.setAttribute("memberList", list);
		request.getRequestDispatcher("/WEB-INF/views/member/list.jsp").forward(request, response);
	}
}
