package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.model.MemberDTO;
import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/mvc/member/insert")
public class MemberInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/views/member/insert.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		String name = request.getParameter("name");
		int laneNumber = Integer.parseInt(request.getParameter("laneNumber"));
		int gameCount = Integer.parseInt(request.getParameter("gameCount"));
		String grade = request.getParameter("grade");

		MemberDTO member = new MemberDTO(0, name, laneNumber, gameCount, grade);

		int result = memberService.insertMember(member);

		if (result > 0) {
			response.sendRedirect(request.getContextPath() + "/mvc/member/list");
		}
	}
}
