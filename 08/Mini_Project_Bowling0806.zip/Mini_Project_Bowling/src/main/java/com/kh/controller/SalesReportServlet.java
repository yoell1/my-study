package com.kh.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// 💡 15번 라인: 주소를 sales로 매핑합니다.
@WebServlet("/mvc/member/sales")
// 💡 16번 라인: 클래스명을 파일 이름과 똑같은 SalesReportServlet으로 수정합니다.
public class SalesReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int[] summary = memberService.getSalesSummary();
		ArrayList<HashMap<String, Object>> billingList = memberService.getBillingList();

		request.setAttribute("summary", summary);
		request.setAttribute("billingList", billingList);

		request.getRequestDispatcher("/WEB-INF/views/member/sales.jsp").forward(request, response);
	}
}
