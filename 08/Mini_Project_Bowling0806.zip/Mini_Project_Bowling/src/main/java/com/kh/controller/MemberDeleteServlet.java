package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/mvc/member/delete")
public class MemberDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService = new MemberService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int bowlerId = Integer.parseInt(request.getParameter("bowlerId"));

		int result = memberService.deleteMemberDirect(bowlerId);

		if (result > 0) {
			response.sendRedirect(request.getContextPath() + "/mvc/member/list");
		}
	}
}
