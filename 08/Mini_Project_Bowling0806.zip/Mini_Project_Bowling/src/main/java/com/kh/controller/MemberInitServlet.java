package com.kh.controller;

import java.io.IOException;

import com.kh.mvc.service.MemberService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/mvc/member/init") // 브라우저 주소창에 칠 주소
public class MemberInitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// 서비스 객체 생성 (기존 소스코드 변수명에 맞춤)
	private MemberService service = new MemberService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. 서비스단을 호출하여 실제 오라클 DB 완전 초기화(비우기) 수행
		service.initializeDatabase();

		// 2. 초기화 완료 후, 회원 목록 조회 URL로 화면을 새로고침(리다이렉트)
		response.sendRedirect(request.getContextPath() + "/mvc/member/list");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
