<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>볼링장 회원 관리 시스템</title>
<!-- 부트스트랩 및 공용 스타일시트 JSTL 표준 경로 매핑 -->
<link href="https://jsdelivr.net" rel="stylesheet">
<link rel="stylesheet" href="https://jsdelivr.net">
<link rel="stylesheet" type="text/css"
	href="<c:url value='/resources/css/style.css'/>">
<script src="<c:url value='/resources/js/member.js'/>" defer></script>
</head>
<body>

	<div class="container">
		<div class="card main-card shadow-sm">
			<h2 class="page-title">
				<i class="bi bi-trophy-fill text-warning"></i> 볼링장 회원 현황 목록
			</h2>

			<div class="btn-group-custom">
				<!-- 모든 주소 제어 링크를 c:url 문법으로 이스케이프 처리 -->
				<button class="btn btn-primary btn-custom shadow-sm"
					onclick="location.href='<c:url value="/mvc/member/insert"/>'">
					<i class="bi bi-person-plus-fill"></i> 신규 볼러 등록
				</button>
				<button class="btn btn-dark btn-custom shadow-sm"
					style="background-color: #6366f1; border: none;"
					onclick="location.href='<c:url value="/mvc/member/sales"/>'">
					<i class="bi bi-graph-up-arrow"></i> 매출 및 정산 통계
				</button>
				<button class="btn btn-danger btn-custom shadow-sm ms-auto"
					onclick="if(confirm('정말 데이터베이스를 포맷하시겠습니까?\n모든 데이터가 즉시 삭제됩니다.')) { location.href='<c:url value="/mvc/member/init"/>'; }">
					<i class="bi bi-exclamation-triangle-fill"></i> DB 완전 초기화
				</button>
			</div>

			<div class="table-container">
				<table class="table table-hover text-center">
					<thead>
						<tr>
							<th>회원고유번호(PK)</th>
							<th>볼러 성명</th>
							<th>배정 레인</th>
							<th>누적 게임 수</th>
							<th>회원 등급</th>
							<th>관리 기능</th>
						</tr>
					</thead>
					<tbody>
						<c:choose>
							<c:when test="${empty memberList}">
								<tr>
									<td colspan="6" class="text-muted py-5"><i
										class="bi bi-folder-x display-6 d-block mb-3 text-black-50"></i>
										현재 등록된 볼링장 회원이 존재하지 않습니다.</td>
								</tr>
							</c:when>
							<c:otherwise>
								<c:forEach var="m" items="${memberList}">
									<tr>
										<td class="text-secondary font-monospace">#<c:out
												value="${m.bowlerId}" /></td>
										<td><strong><c:out value="${m.name}" /></strong></td>
										<td><span class="text-primary fw-bold"><c:out
													value="${m.laneNumber}" /></span>번 레인</td>
										<td><span class="badge bg-light text-dark border"><c:out
													value="${m.gameCount}" />회 이용</span></td>
										<td><c:choose>
												<c:when test="${m.grade eq 'VIP'}">
													<span class="badge badge-vip">VIP GRADE</span>
												</c:when>
												<c:otherwise>
													<span class="badge badge-normal">일반 회원</span>
												</c:otherwise>
											</c:choose></td>
										<td>
											<!-- 파라미터가 포함된 Get 방식 링크도 c:url로 결합하여 안전하게 처리 -->
											<button
												class="btn btn-success action-btn btn-sm shadow-sm me-1"
												onclick="location.href='<c:url value="/mvc/member/pay"><c:param name="bowlerId" value="${m.bowlerId}"/><c:param name="grade" value="${m.grade}"/><c:param name="gameCount" value="${m.gameCount}"/></c:url>'">
												<i class="bi bi-credit-card-2-back-fill"></i> 이용 정산
											</button>
											<button class="btn btn-outline-danger action-btn btn-sm"
												onclick="if(confirm('정말 해당 회원을 퇴실 및 강제 탈퇴 처리하시겠습니까?')) { location.href='<c:url value="/mvc/member/delete"><c:param name="bowlerId" value="${m.bowlerId}"/></c:url>'; }">
												<i class="bi bi-person-x-fill"></i> 강제 탈퇴
											</button>
										</td>
									</tr>
								</c:forEach>
							</c:otherwise>
						</c:choose>
					</tbody>
				</table>
			</div>
		</div>
	</div>

</body>
</html>



