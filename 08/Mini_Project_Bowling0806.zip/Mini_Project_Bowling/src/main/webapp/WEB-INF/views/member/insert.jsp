<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>신규 볼러 회원 등록</title>
<!-- 부트스트랩 및 공용 스타일시트 JSTL 표준 경로 매핑 -->
<link href="https://jsdelivr.net" rel="stylesheet">
<link rel="stylesheet" href="https://jsdelivr.net">
<link rel="stylesheet" type="text/css"
	href="<c:url value='/resources/css/style.css'/>">
</head>
<body>

	<div class="container form-container">
		<div class="card main-card shadow-sm">
			<h2 class="page-title">
				<i class="bi bi-person-plus-fill text-primary"></i> 신규 볼러 회원 등록
			</h2>
			<hr class="mb-4">

			<!-- form action 전송 주소를 JSTL c:url 규격으로 완벽 매핑 -->
			<form action="<c:url value='/mvc/member/insert'/>" method="post">

				<div class="mb-3 text-start">
					<label for="name" class="form-label">볼러 성명</label> <input
						type="text" class="form-control" id="name" name="name"
						placeholder="이름을 입력하세요" required>
				</div>

				<div class="mb-3 text-start">
					<label for="laneNumber" class="form-label">배정 레인 (1-20번)</label> <input
						type="number" class="form-control" id="laneNumber"
						name="laneNumber" min="1" max="20" value="1" required>
				</div>

				<div class="mb-3 text-start">
					<label for="gameCount" class="form-label">누적 게임 수</label> <input
						type="number" class="form-control" id="gameCount" name="gameCount"
						min="0" value="0" required>
				</div>

				<div class="mb-4 text-start">
					<label for="grade" class="form-label">회원 등급</label> <select
						class="form-select" id="grade" name="grade">
						<option value="일반" selected>일반 회원</option>
						<option value="VIP">VIP 회원</option>
					</select>
				</div>

				<div class="row g-2">
					<div class="col-6">
						<button type="submit"
							class="btn btn-primary btn-submit w-100 shadow-sm">등록하기</button>
					</div>
					<div class="col-6">
						<button type="button"
							class="btn btn-outline-secondary btn-cancel w-100"
							onclick="location.href='<c:url value="/mvc/member/list"/>'">취소</button>
					</div>
				</div>

			</form>
		</div>
	</div>

</body>
</html>

