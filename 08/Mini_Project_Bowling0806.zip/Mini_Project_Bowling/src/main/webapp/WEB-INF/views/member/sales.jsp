<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>볼링장 매출 통계 시스템</title>
<!-- 부트스트랩 및 공용 스타일시트 JSTL 표준 경로 매핑 -->
<link href="https://jsdelivr.net" rel="stylesheet">
<link rel="stylesheet" href="https://jsdelivr.net">
<link rel="stylesheet" type="text/css"
	href="<c:url value='/resources/css/style.css'/>">
</head>
<body>

	<div class="container">
		<div class="card main-card shadow-sm">
			<h2 class="page-title">
				<i class="bi bi-wallet2 text-primary"></i> 볼링장 매출 통계 및 정산 이력
			</h2>

			<div class="row g-4">
				<div class="col-md-6">
					<div class="card stat-card-blue shadow-sm">
						<div class="d-flex justify-content-between align-items-center">
							<span class="text-white-50 fw-bold">총 정산 건수</span> <i
								class="bi bi-calculator-fill fs-3"></i>
						</div>
						<div class="stat-value">
							<c:out value="${summary[0]}" />
							건
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="card stat-card-green shadow-sm">
						<div class="d-flex justify-content-between align-items-center">
							<span class="text-white-50 fw-bold">누적 총 매출액</span> <i
								class="bi bi-currency-won fs-3"></i>
						</div>
						<div class="stat-value">
							<fmt:formatNumber value="${summary[1]}" pattern="#,###" />
							원
						</div>
					</div>
				</div>
			</div>

			<h4 class="sub-title">
				<i class="bi bi-list-columns-reverse"></i> 상세 정산 이력 내역
			</h4>

			<div class="table-container shadow-sm mb-4">
				<table class="table table-hover text-center">
					<thead>
						<tr>
							<th>결제 고유 번호(PK)</th>
							<th>퇴실 회원 번호(FK)</th>
							<th>최종 결제 금액</th>
							<th>정산 및 결제 일시</th>
						</tr>
					</thead>
					<tbody>
						<c:choose>
							<c:when test="${empty billingList}">
								<tr>
									<td colspan="4" class="text-muted py-5"><i
										class="bi bi-receipt display-6 d-block mb-3 text-black-50"></i>
										아직 정산 및 퇴실 처리된 매출 내역이 존재하지 않습니다.</td>
								</tr>
							</c:when>
							<c:otherwise>
								<c:forEach var="map" items="${billingList}">
									<tr>
										<td class="font-monospace">#<c:out
												value="${map.billingId}" /></td>
										<td class="text-secondary font-monospace">Member_<c:out
												value="${map.bowlerId}" /></td>
										<td class="text-success fw-bold"><fmt:formatNumber
												value="${map.totalFee}" pattern="#,###" /> 원</td>
										<td class="text-muted font-monospace"><c:out
												value="${map.paymentDate}" /></td>
									</tr>
								</c:forEach>
							</c:otherwise>
						</c:choose>
					</tbody>
				</table>
			</div>

			<div class="pt-3">
				<button class="btn btn-outline-secondary px-4 fw-bold"
					onclick="location.href='<c:url value="/mvc/member/list"/>'">
					<i class="bi bi-arrow-left-short"></i> 회원 목록으로 복귀
				</button>
			</div>
		</div>
	</div>

</body>
</html>



