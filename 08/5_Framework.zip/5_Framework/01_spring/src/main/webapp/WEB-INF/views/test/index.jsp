<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Spring Boot JSP Test</title>
</head>
<body>
    <h1>JSP 포워딩 성공!</h1>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>

	<table>
	    <thead>
	        <tr>
	            <th>순번</th>
	            <th>아이디</th>
	            <th>이름</th>
	        </tr>
	    </thead>
	    <tbody>
	        <!-- 컨트롤러에서 넘겨준 memberList 반복 -->
	        <c:forEach var="member" items="${memberList}" varStatus="status">
	            <tr>
	                <td>${status.count}</td>
	                <td>${member.id}</td>
	                <td>${member.name}</td>
	            </tr>
	        </c:forEach>
	    </tbody>
	</table>
	
	<!-- 1부터 5까지 반복 출력 -->
	<c:forEach var="num" begin="1" end="5">
	    <p>${num}번째 반복 중입니다.</p>
	</c:forEach>
</body>
</html>