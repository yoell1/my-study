<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>홈</title></head>
<body>
	<h1>안녕</h1>
</body>
</html>