<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>게시글 상세</title>
</head>
<body>

	<div>
		<c:choose>
			<c:when test="${empty sessionScope.loginMember}">
				<a href="/member/login">로그인</a>
				<a href="/member/join">회원가입</a>
			</c:when>
			<c:otherwise>
				<b>${sessionScope.loginMember.nickname}</b>님 환영합니다
				<a href="/member/logout">로그아웃</a>
			</c:otherwise>
		</c:choose>
	</div>

	<h1>게시글 상세</h1>

	<table border="1">
		<tr>
			<th>번호</th>
			<td>${board.boardId}</td>
		</tr>
		<tr>
			<th>카테고리</th>
			<td>${board.category}</td>
		</tr>
		<tr>
			<th>제목</th>
			<td>${board.title}</td>
		</tr>
		<tr>
			<th>작성자</th>
			<td>${board.writerNickname}</td>
		</tr>
		<tr>
			<th>조회수</th>
			<td>${board.count}</td>
		</tr>
		<tr>
			<th>작성일</th>
			<td>${board.createAtStr}</td>
		</tr>
		<tr>
			<th>내용</th>
			<td>${board.content}</td>
		</tr>
	</table>

	<br>

	<c:if test="${sessionScope.loginMember.memberId == board.memberId}">

		<a href="/board/modify/${board.boardId}">수정</a>

		<form action="/board/delete" method="post" style="display:inline">
			<input type="hidden" name="boardId" value="${board.boardId}">
			<button type="submit">삭제</button>
		</form>

	</c:if>

	<a href="/board/list">목록으로</a>

</body>
</html>