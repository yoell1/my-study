<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>글수정</title>
</head>
<body>

	<h1>글수정</h1>

	<form action="/board/modify" method="post">

		<input type="hidden" name="boardId" value="${board.boardId}">

		<div>
			카테고리
			<select name="category">
				<option value="자유" <c:if test="${board.category == '자유'}">selected</c:if>>자유</option>
				<option value="질문" <c:if test="${board.category == '질문'}">selected</c:if>>질문</option>
				<option value="공지" <c:if test="${board.category == '공지'}">selected</c:if>>공지</option>
			</select>
		</div>

		<div>
			제목
			<input type="text" name="title" value="${board.title}">
		</div>

		<div>
			내용<br>
			<textarea name="content" rows="10" cols="50">${board.content}</textarea>
		</div>

		<button type="submit">수정</button>

	</form>

	<br>
	<a href="/board/detail/${board.boardId}">취소</a>

</body>
</html>