<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>회원가입</title>
</head>
<body>

	<h1>회원가입</h1>

	<form action="/member/join" method="post">

		<div>
			아이디
			<input type="text" name="memberId">
		</div>

		<div>
			비밀번호
			<input type="password" name="memberPwd">
		</div>

		<div>
			이름
			<input type="text" name="memberName">
		</div>

		<div>
			닉네임
			<input type="text" name="nickname">
		</div>

		<div>
			이메일
			<input type="email" name="email">
		</div>

		<br>
		<button type="submit">가입</button>

	</form>

</body>
</html>