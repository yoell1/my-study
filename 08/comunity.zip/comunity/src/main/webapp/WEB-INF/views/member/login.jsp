<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>로그인</title>
</head>
<body>
	<form action="/member/login" method="post">
		아이디   <input type="text" name="memberId">
		비밀번호 <input type="password" name="memberPwd">
		<button type="submit">로그인</button>
	</form>

</body>
</html>
