<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>게시글 목록</title>
</head>
<body>

	<div>
		<c:choose>
			<c:when test="${empty sessionScope.loginMember}">
				<a href="/member/login">로그인</a>
				<a href="/member/join">회원가입</a>
			</c:when>
			<c:otherwise>
				<b>${sessionScope.loginMember.nickname}</b>님 환영합니다
				<a href="/member/logout">로그아웃</a>
			</c:otherwise>
		</c:choose>
	</div>

	<h1>게시글 목록</h1>

	<a href="/board/write">글쓰기</a>

	<table border="1">
		<thead>
			<tr>
				<th>번호</th>
				<th>카테고리</th>
				<th>제목</th>
				<th>작성자</th>
				<th>조회수</th>
				<th>작성일</th>
			</tr>
		</thead>
		<tbody>
			<c:forEach var="board" items="${boardList}">
				<tr>
					<td>${board.boardId}</td>
					<td>${board.category}</td>
					<td><a href="/board/detail/${board.boardId}">${board.title}</a></td>
					<td>${board.writerNickname}</td>
					<td>${board.count}</td>
					<td>${board.createAtStr}</td>
				</tr>
			</c:forEach>
		</tbody>
	</table>

</body>
</html>