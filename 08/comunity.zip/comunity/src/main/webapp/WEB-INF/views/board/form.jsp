<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>글쓰기</title>
</head>
<body>

	<h1>글쓰기</h1>

	<form action="/board/write" method="post">

		<div>
			카테고리
			<select name="category">
				<option value="자유">자유</option>
				<option value="질문">질문</option>
				<option value="공지">공지</option>
			</select>
		</div>

		<div>
			제목
			<input type="text" name="title">
		</div>

		<div>
			내용<br>
			<textarea name="content" rows="10" cols="50"></textarea>
		</div>

		<button type="submit">등록</button>

	</form>

	<br>
	<a href="/board/list">목록으로</a>

</body>
</html>