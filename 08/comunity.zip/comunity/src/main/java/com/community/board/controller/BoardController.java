package com.community.board.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.community.board.model.dto.BoardDTO;
import com.community.board.service.BoardService;
import com.community.common.SessionConst;
import com.community.member.model.dto.MemberDTO;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/board")
public class BoardController {

	private final BoardService boardService;

	public BoardController(BoardService boardService) {
		this.boardService = boardService;
	}

	@GetMapping("/list")
	public String boardList(Model model) {

		List<BoardDTO> list = boardService.getBoardList();

		model.addAttribute("boardList", list);

		return "board/list";
	}

	@GetMapping("/detail/{boardId}")
	public String detail(@PathVariable Long boardId, Model model) {

		BoardDTO board = boardService.getBoardDetail(boardId);

		model.addAttribute("board", board);

		return "board/detail";
	}

	@GetMapping("/write")
	public String writeForm() {
		return "board/form";
	}

	@PostMapping("/write")
	public String write(@ModelAttribute BoardDTO board, HttpSession session) {

		MemberDTO loginMember = (MemberDTO) session.getAttribute(SessionConst.LOGIN_MEMBER);

		board.setMemberId(loginMember.getMemberId());

		Long boardId = boardService.writeBoard(board);

		return "redirect:/board/detail/" + boardId;
	}

	
	@PostMapping("/delete")
	public String delete(Long boardId, HttpSession session) {

		MemberDTO loginMember = (MemberDTO) session.getAttribute(SessionConst.LOGIN_MEMBER);

		boardService.removeBoard(boardId, loginMember.getMemberId());

		return "redirect:/board/list";
	}
	
	@GetMapping("/modify/{boardId}")
	public String modifyForm(@PathVariable Long boardId,
	                         Model model,
	                         HttpSession session) {

		BoardDTO board = boardService.getBoardForModify(boardId);

		// ① 없는 글이면 목록으로
		if (board == null) {
			return "redirect:/board/list";
		}

		// ② 남의 글이면 상세로
		MemberDTO loginMember = (MemberDTO) session.getAttribute(SessionConst.LOGIN_MEMBER);

		if (!board.getMemberId().equals(loginMember.getMemberId())) {
			return "redirect:/board/detail/" + boardId;
		}

		model.addAttribute("board", board);
		return "board/modify";
	
	}
	
	@PostMapping("/modify")
	public String modify(@ModelAttribute BoardDTO board, HttpSession session) {

		MemberDTO loginMember = (MemberDTO) session.getAttribute(SessionConst.LOGIN_MEMBER);

		boolean result = boardService.modifyBoard(board, loginMember.getMemberId());

		if (!result) {
			return "redirect:/board/list";
		}

		return "redirect:/board/detail/" + board.getBoardId();
	}

}