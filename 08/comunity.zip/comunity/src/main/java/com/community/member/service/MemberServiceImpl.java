package com.community.member.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.community.member.model.dto.MemberDTO;
import com.community.member.model.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {

	private final MemberMapper memberMapper;
	private final PasswordEncoder passwordEncoder;
	
	
	
	
	public MemberServiceImpl(MemberMapper memberMapper, PasswordEncoder passwordEncoder) {
		
		this.memberMapper = memberMapper;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public void join(MemberDTO member) {

		String plain = member.getMemberPwd();              // ① 평문 꺼내기

		String encoded = passwordEncoder.encode(plain);    // ② 암호화하기

		member.setMemberPwd(encoded);                      // ③ 덮어쓰기

		memberMapper.insertMember(member);                 // ④ 저장
	}

	@Override
	public boolean isIdAvailable(String memberId) {
		
		return memberMapper.countById(memberId) == 0;
		
	}

	@Override
	public MemberDTO login(String memberId, String memberPwd) {

		MemberDTO member = memberMapper.selectMemberById(memberId);

		if (member == null) {
			return null;
		}

		if (!passwordEncoder.matches(memberPwd, member.getMemberPwd())) {
			return null;
		}

		return member;
	}
	
	
	

	
}
