package com.community.member.model.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.community.member.model.dto.MemberDTO;

@Mapper
public interface MemberMapper {
	
	int insertMember(MemberDTO member);
	
	MemberDTO selectMemberById(String memberId);
	
	int countById(String memberId);
	
	
	

}
