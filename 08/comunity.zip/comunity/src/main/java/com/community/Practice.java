package com.community;

public class Practice {

	// ══════════════════════════════════════════
	//  선언 구역 — 여기는 건드리지 마세요
	//  메소드가 어떻게 생겼는지 정의만 해둔 곳
	// ══════════════════════════════════════════

	public static int add(int a, int b) {
		return a + b;
	}

	public static int multiply(int x, int y) {
		return x * y;
	}

	public static String greet(String name) {
		return name + "님 안녕하세요";
	}


	// ══════════════════════════════════════════
	//  호출 구역 — 여기에만 코드를 쓰세요
	//  실제로 실행되는 곳
	// ══════════════════════════════════════════

	public static void main(String[] args) {

		// ── 예시 ──────────────────────────────
		// 3과 5를 더한 결과를 sum 에 담고 출력

		int sum = add(3, 5);
		System.out.println(sum);


		// ── 연습 1 ────────────────────────────
		// 4와 7을 곱한 결과를 result 에 담고 출력
		// 위의 예시를 그대로 흉내내면 됩니다
		// multiply 라는 이름을 쓰고, 값 두 개를 넣으세요

		int result = 4*7;
		System.out.println(result);
//		
//		① 10과 20을 더해서 출력
//		② 6과 6을 곱해서 출력
//		③ "우진" 에게 인사해서 출력
		
		int sum1 = add(10,20);
		System.out.println(sum);
		
		int result1 = multiply(6,6);
		System.out.println(result1);
		
		String msg = greet("우진");
		System.out.println(msg);
		

	}
}
