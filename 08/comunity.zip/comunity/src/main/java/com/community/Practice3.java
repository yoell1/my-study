package com.community;

public class Practice3 {

	public static void main(String[] args) {

		System.out.println("--- 1번 ---");
		String a = "user01";
		String b = "user01";
		System.out.println(a == b);
		System.out.println(a.equals(b));


		System.out.println("--- 2번 ---");
		String c = "user01";
		String d = new String("user01");
		System.out.println(c == d);
		System.out.println(c.equals(d));


		System.out.println("--- 3번 ---");
		String e = "user";
		String f = e + "01";
		System.out.println(f);
		System.out.println(c == f);
		System.out.println(c.equals(f));


		System.out.println("--- 4번 ---");
		int x = 5;
		int y = 5;
		System.out.println(x == y);

	}
}
