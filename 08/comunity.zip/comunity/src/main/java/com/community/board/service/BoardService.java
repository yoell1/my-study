package com.community.board.service;

import java.util.List;

import com.community.board.model.dto.BoardDTO;


public interface BoardService {
	
	List<BoardDTO> getBoardList();
	
	BoardDTO getBoardDetail(Long boardId);

	Long writeBoard(BoardDTO board);

	BoardDTO getBoardForModify(Long boardId);

	boolean modifyBoard(BoardDTO board, String loginMemberId);
	
	boolean removeBoard(Long boardId, String loginMemberId);
}
