package com.community.common;

public class SessionConst {

	public static final String LOGIN_MEMBER = "loginMember";
}