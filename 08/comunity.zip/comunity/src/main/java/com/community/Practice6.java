package com.community;

public class Practice6 {

	// ══════════════════════════════════════════════════════
	//  선언 구역 — 여기에 메소드를 만드세요
	//  아래 main 이 부르고 있는 것들입니다
	// ══════════════════════════════════════════════════════


	// ── 문제 1 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  int v1 = triple(4);
	// 받은 숫자에 3을 곱해서 돌려주세요
	public static int triple(int v1) {
		return v1*3;
	}




	// ── 문제 2 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  String v2 = wrap("안녕");
	// 받은 글자 양옆에 [ ] 를 붙여서 돌려주세요.  결과 [안녕]
	public static String wrap(String v2) {
		return "["+v2+"]";
	}




	// ── 문제 3 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  boolean v3 = isLong("hello");
	// 글자 길이가 5 이상이면 true 를 돌려주세요
	// 길이는  text.length()  로 구합니다
	public static boolean isLong(String text) {
		return text.length() >= 5;
	}




	// ── 문제 4 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  int v4 = minus(10, 3);
	// 앞 숫자에서 뒤 숫자를 빼서 돌려주세요
	public static int minus(int a , int b) {
	return  a -b;
	}




	// ── 문제 5 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  printTwice("야호");
	// 받은 글자를 두 번 출력하세요.  돌려주는 값은 없습니다
	public static void printTwice(String text) {
		 System.out.println(text);
		 System.out.println(text);
	}




	// ── 문제 6 ──────────────────────────────────────────
	// main 에서 이렇게 부릅니다:  String v6 = between("사과", "포도", 2);
	// 세 번째 값이 1이면 첫 번째 글자를, 아니면 두 번째 글자를 돌려주세요
	public static String between(String a, String b, int c) {
		if(c == 1) {
			return a;
		}
			return b;
		
	}




	// ══════════════════════════════════════════════════════
	//  호출 구역 — 건드리지 마세요
	//  위를 다 만들면 에러가 사라집니다
	// ══════════════════════════════════════════════════════

	public static void main(String[] args) {

		int v1 = triple(4);
		System.out.println(v1);

		String v2 = wrap("안녕");
		System.out.println(v2);

		boolean v3 = isLong("hello");
		System.out.println(v3);

		int v4 = minus(10, 3);
		System.out.println(v4);

		printTwice("야호");

		String v6 = between("사과", "포도", 2);
		System.out.println(v6);

	}
}
