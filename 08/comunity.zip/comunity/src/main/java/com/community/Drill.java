package com.community;

public class Drill {

	// ══════════════════════════════════════════════════════
	//
	//  선언 만들기 드릴 — 10문제
	//
	//  매번 이 순서로 하세요:
	//
	//    ① 호출문의 왼쪽 타입을 본다      →  나갈 타입
	//    ② 메소드 이름을 본다             →  이름
	//    ③ 괄호 안 값의 종류를 본다        →  들어올 타입
	//    ④ public static 을 앞에 붙인다
	//    ⑤ return 을 잊지 않는다
	//
	// ══════════════════════════════════════════════════════


	// ── 1 ──  호출:  int a = plus10(5);
	//          받은 수에 10을 더해 돌려주세요
	public static int plus10(int n) {
		return n + 10;
	}




	// ── 2 ──  호출:  int b = minus10(5);
	//          받은 수에서 10을 빼서 돌려주세요
public static int minus10(int n) {
	return n - 10 ;
}




	// ── 3 ──  호출:  int c = times10(5);
	//          받은 수에 10을 곱해 돌려주세요
public static int times10(int n) {
	return n*10;
}



	// ── 4 ──  호출:  String d = addBang("안녕");
	//          받은 글자 뒤에 ! 를 붙여 돌려주세요
public static String addBang(String d) {
	return d + "!";
}



	// ── 5 ──  호출:  String e = addQ("안녕");
	//          받은 글자 뒤에 ? 를 붙여 돌려주세요
public static String addQ(String e) {
	return e+"?";
}




	// ── 6 ──  호출:  String f = addDot("안녕");
	//          받은 글자 뒤에 . 을 붙여 돌려주세요
public static String addDot(String f) {
	return f+".";
}



	// ── 7 ──  호출:  boolean g = isBig(50);
	//          받은 수가 100 보다 크면 true

public static boolean isBig(int g) {
	return g > 100 ;
}


	// ── 8 ──  호출:  boolean h = isSmall(50);
	//          받은 수가 10 보다 작으면 true
public static boolean isSmall(int h) {
	return h <10;
}




	// ── 9 ──  호출:  boolean i = isZero(50);
	//          받은 수가 0 이면 true.  숫자 비교는 ==
public static boolean isZero(int i) {
	return i == 0;
}



	// ── 10 ──  호출:  boolean j = isSame("가", "나");
	//           받은 두 글자가 같으면 true.  문자열 비교는 .equals()

public static boolean isSame(String a, String b) {
	return a.equals(b);
}


	// ══════════════════════════════════════════════════════
	//  건드리지 마세요
	// ══════════════════════════════════════════════════════

	public static void main(String[] args) {

		int a = plus10(5);
		int b = minus10(5);
		int c = times10(5);
		System.out.println(a + " " + b + " " + c);

		String d = addBang("안녕");
		String e = addQ("안녕");
		String f = addDot("안녕");
		System.out.println(d + " " + e + " " + f);

		boolean g = isBig(50);
		boolean h = isSmall(50);
		boolean i = isZero(50);
		boolean j = isSame("가", "나");
		System.out.println(g + " " + h + " " + i + " " + j);

	}
}
