package com.community;

public class Practice5 {

	// ══════════════════════════════════════════════════════
	//  선언 구역 — 건드리지 마세요
	// ══════════════════════════════════════════════════════

	public static int half(int n) {
		return n / 2;
	}

	public static String upper(String word) {
		return word.toUpperCase();
	}

	public static boolean isEmpty(String text) {
		return text.length() == 0;
	}

	public static String join(String a, String b, String glue) {
		return a + glue + b;
	}

	public static int max(int a, int b) {
		if (a > b) {
			return a;
		}
		return b;
	}

	public static String grade(int score) {
		if (score >= 90) {
			return "A";
		}
		if (score >= 80) {
			return "B";
		}
		return "C";
	}


	// ══════════════════════════════════════════════════════
	//  호출 구역 — 여기에만 쓰세요
	//  변수 이름은 겹치지 않게 v1, v2, v3 ... 으로 쓰세요
	// ══════════════════════════════════════════════════════

	public static void main(String[] args) {

		// ── 문제 1 ──────────────────────────────────────
		// 100 의 절반을 출력하세요
		System.out.println(half(100));




		// ── 문제 2 ──────────────────────────────────────
		// "hello" 를 대문자로 바꿔서 출력하세요
		System.out.println(upper("hello"));




		// ── 문제 3 ──────────────────────────────────────
		// "" (빈 글자) 가 비었는지 판정해서 출력하세요
		// 받는 변수의 타입에 주의
		System.out.println(isEmpty(""));




		// ── 문제 4 ──────────────────────────────────────
		// "김치" 와 "찌개" 를 "-" 로 이어서 출력하세요
		// 결과는 김치-찌개
		System.out.println(join("김치","찌개","-"));




		// ── 문제 5 ──────────────────────────────────────
		// 17 과 42 중 큰 값을 출력하세요
		System.out.println(max(42,17));




		// ── 문제 6 ──────────────────────────────────────
		// 점수 85 의 등급을 출력하세요
		System.out.println(grade(85));




		// ── 문제 7 ──────────────────────────────────────
		// 80 의 절반의 절반을 출력하세요
		// half 를 두 번 씁니다. 답은 20
		System.out.println(half(half(80)));




		// ── 문제 8 ──────────────────────────────────────
		// "java" 를 대문자로 바꾼 것과 "SPRING" 을 " + " 로 이어서 출력
		// 결과는 JAVA + SPRING
		System.out.println(upper("java")+ "+" +upper("spring"));




	}
}
