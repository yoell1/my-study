package com.community;

public class Practice4 {

	// ══════════════════════════════════════════════════════
	//  선언 구역 — 절대 건드리지 마세요
	//  여기 있는 것들을 아래에서 "부르기만" 하면 됩니다
	// ══════════════════════════════════════════════════════

	public static int square(int n) {
		return n * n;
	}

	public static String repeat(String word, int times) {
		String result = "";
		for (int i = 0; i < times; i++) {
			result = result + word;
		}
		return result;
	}

	public static boolean isAdult(int age) {
		return age >= 19;
	}

	public static String pick(String a, String b, boolean useFirst) {
		if (useFirst) {
			return a;
		}
		return b;
	}

	public static int sum(int a, int b, int c) {
		return a + b + c;
	}


	// ══════════════════════════════════════════════════════
	//  호출 구역 — 여기에만 쓰세요
	// ══════════════════════════════════════════════════════

	public static void main(String[] args) {

		// ── 예시 ───────────────────────────────────────
		// 5의 제곱을 구해서 출력

		int a = square(5);
		System.out.println(a);


		// ── 연습 1 ─────────────────────────────────────
		// 9의 제곱을 구해서 출력하세요

		int b = square(9);
		System.out.println(b);



		// ── 연습 2 ─────────────────────────────────────
		// "야" 를 3번 반복한 결과를 출력하세요
		// repeat 을 쓰세요
		System.out.println(repeat("야",3));




		// ── 연습 3 ─────────────────────────────────────
		// 나이 20이 성인인지 판정해서 출력하세요
		// isAdult 를 쓰세요. 결과 타입에 주의
		System.out.println(isAdult(20));




		// ── 연습 4 ─────────────────────────────────────
		// "사과" 와 "포도" 중 두 번째 것을 골라서 출력하세요
		// pick 을 쓰세요
		System.out.println(pick("사과","포도",true));




		// ── 연습 5 ─────────────────────────────────────
		// 1, 2, 3 을 더해서 출력하세요
		System.out.println(sum(1,2,3));




		// ── 연습 6 ─────────────────────────────────────
		// 3의 제곱과 4의 제곱을 더한 값을 출력하세요
		// square 를 두 번, sum 은 안 씁니다
		System.out.println(square(3)+square(4));




	}
}
