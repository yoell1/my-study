package com.community;

import java.util.ArrayList;
import java.util.List;

public class ListDrill {

	public static void main(String[] args) {

		// ══════════════════════════════════════════════
		//  1. List 는 값을 여러 개 담는 상자
		// ══════════════════════════════════════════════

		
		System.out.println("--- 1번 ---");

		List<String> names = new ArrayList<>();

		names.add("우진");
		names.add("민수");
		names.add("영희");

		System.out.println(names.size());
		System.out.println(names.get(0));
		System.out.println(names.get(2));
		

		// ══════════════════════════════════════════════
		//  2. 반복문 — 하나씩 꺼내서 처리
		// ══════════════════════════════════════════════

		System.out.println("--- 2번 ---");

		for (String name : names) {
			System.out.println(name + "님");
		}


		// ══════════════════════════════════════════════
		//  3. 숫자 List 도 같은 방식
		// ══════════════════════════════════════════════

		System.out.println("--- 3번 ---");

		List<Integer> scores = new ArrayList<>();
		scores.add(90);
		scores.add(85);
		scores.add(70);

		for (int score : scores) {
			System.out.println(score);
		}


		// ══════════════════════════════════════════════
		//  4. 빈 List
		// ══════════════════════════════════════════════

		System.out.println("--- 4번 ---");

		List<String> empty = new ArrayList<>();

		System.out.println(empty.size());

		for (String s : empty) {
			System.out.println("이 줄은 실행될까?");
		}

		System.out.println("4번 끝");


		// ══════════════════════════════════════════════
		//  연습 1
		//  fruits 라는 List<String> 을 만들고
		//  "사과" "바나나" "포도" 를 넣은 뒤
		//  반복문으로 하나씩 출력하세요
		// ══════════════════════════════════════════════

		System.out.println("--- 연습 1 ---");
		
		List<String> fruits = new ArrayList<>();
		
		fruits.add("사과");
		fruits.add("바나나");
		fruits.add("포도");
		
		for(String name : fruits) {
			System.out.println(name);
		}




	}
}
