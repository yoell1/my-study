package com.community;

public class Practice2 {

	// ══════════════════════════════════════════
	//  Person — 사람 하나를 담는 상자
	//  건드리지 마세요
	// ══════════════════════════════════════════

	static class Person {

		private String name;
		private int age;

		// 값을 넣는 메소드 (세터)
		public void setName(String name) {
			this.name = name;
		}

		public void setAge(int age) {
			this.age = age;
		}

		// 값을 꺼내는 메소드 (게터)
		public String getName() {
			return name;
		}

		public int getAge() {
			return age;
		}
	}


	// ══════════════════════════════════════════
	//  호출 구역 — 여기에만 쓰세요
	// ══════════════════════════════════════════

	public static void main(String[] args) {

		// ── 예시 ──────────────────────────────
		// 상자를 하나 만들고, 값을 넣고, 꺼내서 출력

		Person p1 = new Person();

		p1.setName("우진");
		p1.setAge(27);

		System.out.println(p1.getName());
		System.out.println(p1.getAge());


		// ── 연습 1 ────────────────────────────
		// p2 라는 상자를 새로 만들고
		// 이름은 "민수", 나이는 30 을 넣은 뒤
		// 둘 다 출력하세요
		// 위 예시를 그대로 흉내내면 됩니다
		
		Person p2 = new Person();
		
		p2.setName("민수");
		p2.setAge(30);
		
		System.out.println(p2.getName());
		System.out.println(p2.getAge());




	}
}
