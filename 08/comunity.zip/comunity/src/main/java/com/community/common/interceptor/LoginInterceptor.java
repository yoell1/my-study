package com.community.common.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;

import com.community.common.SessionConst;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginInterceptor implements HandlerInterceptor {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler)
			throws Exception {

		// ① 세션 가져오기
		HttpSession session = request.getSession(false);

		// ② 로그인 상태인지 확인
		boolean isLoggedIn = session != null
				&& session.getAttribute(SessionConst.LOGIN_MEMBER) != null;

		// ③ 로그인했으면 통과
		if (isLoggedIn) {
			return true;
		}

		// ④ 아니면 로그인 화면으로
		response.sendRedirect("/member/login");
		return false;
	}
}