package com.community.member.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.community.common.SessionConst;
import com.community.member.model.dto.MemberDTO;
import com.community.member.service.MemberService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/member")
public class MemberController {

	private final MemberService memberService;

	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}

	@GetMapping("/join")
	public String joinForm() {
		return "member/join";
	}

	@PostMapping("/join")
	public String join(@ModelAttribute MemberDTO member) {
		memberService.join(member);
		return "redirect:/board/list";
	}

	@GetMapping("/login")
	public String loginForm() {
		return "member/login";
	}

	@PostMapping("/login")
	public String login(String memberId, String memberPwd, HttpSession session) {

		MemberDTO loginMember = memberService.login(memberId, memberPwd);

		if (loginMember == null) {
			return "redirect:/member/login";
		}

		session.setAttribute(SessionConst.LOGIN_MEMBER, loginMember);

		return "redirect:/board/list";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/board/list";
	}
}