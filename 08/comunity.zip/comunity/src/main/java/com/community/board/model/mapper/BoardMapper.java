package com.community.board.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.community.board.model.dto.BoardDTO;

@Mapper
public interface BoardMapper {
	
	List<BoardDTO> selectBoardList();
	
	int increaseViewCount(Long boardId);

	BoardDTO selectBoardDetail(Long boardId);
	
	int insertBoard(BoardDTO board);
	
    int updateBoard(BoardDTO board);
	
	int deleteBoard(Long boardId);

}
