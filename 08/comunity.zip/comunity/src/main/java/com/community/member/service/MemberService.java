package com.community.member.service;

import com.community.member.model.dto.MemberDTO;


public interface MemberService {
	
	void join(MemberDTO member);            // 회원가입
	
	boolean isIdAvailable(String memberId); // 아이디 사용 가능?
	
	MemberDTO login(String memberId, String memberPwd);

}
