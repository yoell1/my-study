package com.community.board.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.community.board.model.dto.BoardDTO;
import com.community.board.model.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {

	private final BoardMapper boardMapper;

	public BoardServiceImpl(BoardMapper boardMapper) {
		this.boardMapper = boardMapper;
	}

	@Override
	public List<BoardDTO> getBoardList() {
		return boardMapper.selectBoardList();
	}

	@Override
	public BoardDTO getBoardDetail(Long boardId) {

		boardMapper.increaseViewCount(boardId);

		return boardMapper.selectBoardDetail(boardId);
	}

	@Override
	public Long writeBoard(BoardDTO board) {

		boardMapper.insertBoard(board);

		return board.getBoardId();
	}

	@Override
	public boolean removeBoard(Long boardId, String loginMemberId) {

		BoardDTO origin = boardMapper.selectBoardDetail(boardId);

		if (origin == null) {
			return false;
		}

		if (!origin.getMemberId().equals(loginMemberId)) {
			return false;
		}

		return boardMapper.deleteBoard(boardId) > 0;
	}

	@Override
	public BoardDTO getBoardForModify(Long boardId) {
		return boardMapper.selectBoardDetail(boardId);
	}
	
	
	@Override
	public boolean modifyBoard(BoardDTO board, String loginMemberId) {

		BoardDTO origin = boardMapper.selectBoardDetail(board.getBoardId());

		if (origin == null) {
			return false;
		}

		if (!origin.getMemberId().equals(loginMemberId)) {
			return false;
		}

		return boardMapper.updateBoard(board) > 0;
	}

}