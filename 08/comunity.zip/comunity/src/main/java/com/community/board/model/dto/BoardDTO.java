package com.community.board.model.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class BoardDTO {

	private Long boardId;
	private String memberId;
	private String category;
	private String title;
	private String content;
	private int count;
	private LocalDateTime createAt;
	private LocalDateTime updateAt;
	
	private String writerNickname;
	private String createAtStr;
	private String updateAtStr;
}
