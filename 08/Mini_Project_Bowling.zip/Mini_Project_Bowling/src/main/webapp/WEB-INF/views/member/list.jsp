<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList, com.kh.mvc.model.MemberDTO"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>볼러 회원 현황</title>
<style>
body {
	font-family: 'Malgun Gothic', sans-serif;
	margin: 50px;
}

table {
	width: 950px;
	border-collapse: collapse;
	margin-top: 20px;
}

th, td {
	border: 1px solid #bdc3c7;
	padding: 10px;
	text-align: center;
}

th {
	background-color: #34495e;
	color: white;
}

tr:nth-child(even) {
	background-color: #f2f2f2;
}

.btn-add {
	padding: 10px 20px;
	background-color: #2980b9;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
	font-weight: bold;
}

.btn-pay {
	padding: 4px 8px;
	background-color: #27ae60;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
	font-size: 12px;
	font-weight: bold;
}

.btn-del {
	padding: 4px 8px;
	background-color: #c0392b;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
	font-size: 12px;
	font-weight: bold;
}
</style>
<script>
    function checkDelete(bowlerId) {
        if(confirm(bowlerId + "번 회원을 정말 탈퇴 처리하시겠습니까?")) {
            location.href = "${pageContext.request.contextPath}/mvc/member/delete?bowlerId=" + bowlerId;
        }
    }
    function checkPay(bowlerId, grade, gameCount) {
        if(confirm(bowlerId + "번 회원의 게임 이용료를 정산하고 퇴실시킵니까?")) {
            location.href = "${pageContext.request.contextPath}/mvc/member/pay?bowlerId=" + bowlerId + "&grade=" + grade + "&gameCount=" + gameCount;
        }
    }
</script>
</head>
<body>
	<h2>볼링장 회원 현황 목록</h2>
	<hr>
	<br>
	<button class="btn-add"
		onclick="location.href='${pageContext.request.contextPath}/mvc/member/insert'">신규
		볼러 등록</button>
	<!-- 보라색 매출 통계 버튼 연결 완료 -->
	<button class="btn-add"
		style="background-color: #8e44ad; margin-left: 5px;"
		onclick="location.href='${pageContext.request.contextPath}/mvc/member/sales'">
		매출 및 정산 통계</button>

	<table>
		<thead>
			<tr>
				<th>회원고유번호(PK)</th>
				<th>볼러 성명</th>
				<th>배정 레인</th>
				<th>누적 게임 수</th>
				<th>회원 등급</th>
				<th>관리 기능</th>
			</tr>
		</thead>
		<tbody>
			<%
			ArrayList<MemberDTO> list = (ArrayList<MemberDTO>) request.getAttribute("memberList");
			if (list == null || list.isEmpty()) {
			%>
			<tr>
				<td colspan="6" style="color: #7f8c8d; padding: 30px;">현재 등록된
					볼링장 회원이 없습니다.</td>
			</tr>
			<%
			} else {
			for (MemberDTO m : list) {
			%>
			<tr>
				<td><%=m.getBowlerId()%></td>
				<td><%=m.getName()%></td>
				<td><%=m.getLaneNumber()%>번 레인</td>
				<td><%=m.getGameCount()%>회 이용</td>
				<td>
					<%
					if ("VIP".equals(m.getGrade())) {
					%> <strong style="color: #e74c3c;"><%=m.getGrade()%></strong> <%
 } else {
 %> <%=m.getGrade()%> <%
 }
 %>
				</td>
				<td>
					<button class="btn-pay"
						onclick="checkPay(<%=m.getBowlerId()%>, '<%=m.getGrade()%>', <%=m.getGameCount()%>)">이용
						정산</button>
					<button class="btn-del" onclick="checkDelete(<%=m.getBowlerId()%>)">강제
						탈퇴</button>
				</td>
			</tr>
			<%
			}
			}
			%>
		</tbody>
	</table>
</body>
</html>

