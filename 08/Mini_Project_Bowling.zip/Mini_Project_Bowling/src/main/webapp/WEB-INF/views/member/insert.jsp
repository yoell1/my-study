<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>볼러 신규 등록</title>
<style>
body {
	font-family: 'Malgun Gothic', sans-serif;
	margin: 50px;
}

form {
	width: 400px;
	padding: 20px;
	border: 1px solid #ccc;
	border-radius: 5px;
}

label {
	display: inline-block;
	width: 150px;
	margin-bottom: 10px;
	font-weight: bold;
}

input[type="text"], input[type="number"], select {
	width: 220px;
	padding: 5px;
	margin-bottom: 15px;
}

.btn-group {
	text-align: center;
	margin-top: 10px;
}

input[type="submit"] {
	padding: 7px 15px;
	background-color: #27ae60;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
}

button {
	padding: 7px 15px;
	background-color: #7f8c8d;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
}
</style>
</head>
<body>
	<h2>신규 볼러 회원 등록</h2>
	<hr>
	<br>

	<!-- /mpb/mvc/member/insert 서블릿 주소로 POST 전송 -->
	<form action="${pageContext.request.contextPath}/mvc/member/insert"
		method="post">
		<label>볼러 성명</label> <input type="text" name="name"
			placeholder="이름을 입력하세요" required><br> <label>배정
			레인 (1-20번)</label> <input type="number" name="laneNumber" min="1" max="20"
			placeholder="1" required><br> <label>누적 게임 수</label> <input
			type="number" name="gameCount" min="0" value="0" required><br>

		<label>회원 등급</label> <select name="grade">
			<option value="일반">일반 회원</option>
			<option value="VIP">VIP 회원</option>
		</select><br>

		<div class="btn-group">
			<input type="submit" value="등록하기">
			<button type="button"
				onclick="location.href='${pageContext.request.contextPath}/mvc/member/list'">취소</button>
		</div>
	</form>
</body>
</html>
