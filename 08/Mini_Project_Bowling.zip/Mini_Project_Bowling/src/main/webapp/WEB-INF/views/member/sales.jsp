<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList, java.util.HashMap"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>매출 및 정산 관리</title>
<style>
body {
	font-family: 'Malgun Gothic', sans-serif;
	margin: 50px;
}

.summary-box {
	display: flex;
	gap: 20px;
	margin-bottom: 30px;
}

.card {
	flex: 1;
	padding: 20px;
	border-radius: 5px;
	color: white;
	text-align: center;
	box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.card-blue {
	background-color: #2980b9;
}

.card-green {
	background-color: #27ae60;
}

.card h3 {
	margin: 0 0 10px 0;
	font-size: 16px;
	opacity: 0.9;
}

.card p {
	margin: 0;
	font-size: 28px;
	font-weight: bold;
}

table {
	width: 800px;
	border-collapse: collapse;
	margin-top: 20px;
}

th, td {
	border: 1px solid #bdc3c7;
	padding: 10px;
	text-align: center;
}

th {
	background-color: #2c3e50;
	color: white;
}

tr:nth-child(even) {
	background-color: #f9f9f9;
}

.btn-back {
	padding: 10px 20px;
	background-color: #7f8c8d;
	color: white;
	border: none;
	cursor: pointer;
	border-radius: 3px;
	font-weight: bold;
}
</style>
</head>
<body>
	<h2>볼링장 매출 통계 및 정산 이력 (`BILLING`)</h2>
	<hr>
	<br>

	<%
	int[] summary = (int[]) request.getAttribute("summary");
	ArrayList<HashMap<String, Object>> billingList = (ArrayList<HashMap<String, Object>>) request
			.getAttribute("billingList");

	// 원화 포맷팅을 위한 변수
	java.text.DecimalFormat df = new java.text.DecimalFormat("#,###");
	%>

	<!-- 1. 상단 대시보드 통계 카드 박스 -->
	<div class="summary-box">
		<div class="card card-blue">
			<h3>총 정산 건수</h3>
			<p><%=summary[0]%>건
			</p>
		</div>
		<div class="card card-green">
			<h3>누적 총 매출액</h3>
			<p>
				₩
				<%=df.format(summary[1])%>
				원
			</p>
		</div>
	</div>

	<h3>상세 정산 이력 내역</h3>
	<table>
		<thead>
			<tr>
				<th>결제 고유 번호(PK)</th>
				<th>퇴실 회원 번호(FK)</th>
				<th>최종 결제 금액</th>
				<th>정산 및 결제 일시</th>
			</tr>
		</thead>
		<tbody>
			<%
			if (billingList == null || billingList.isEmpty()) {
			%>
			<tr>
				<td colspan="4" style="color: #7f8c8d; padding: 30px;">아직 정산 및
					퇴실 처리된 내역이 존재하지 않습니다.</td>
			</tr>
			<%
			} else {
			for (HashMap<String, Object> map : billingList) {
			%>
			<tr>
				<td><%=map.get("billingId")%></td>
				<td><%=map.get("bowlerId")%>번 회원</td>
				<td style="font-weight: bold; color: #27ae60;">₩ <%=df.format(map.get("totalFee"))%>
					원
				</td>
				<td><%=map.get("paymentDate")%></td>
			</tr>
			<%
			}
			}
			%>
		</tbody>
	</table>

	<br>
	<br>
	<button class="btn-back"
		onclick="location.href='${pageContext.request.contextPath}/mvc/member/list'">회원
		목록으로 복귀</button>
</body>
</html>
