package com.kh.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.kh.mvc.util.DBUtil;
import com.kh.mvc.model.MemberDAO;

@WebServlet("/mvc/member/pay")
public class MemberPayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();

		int bowlerId = Integer.parseInt(request.getParameter("bowlerId"));
		String grade = request.getParameter("grade");
		int gameCount = Integer.parseInt(request.getParameter("gameCount"));

		if (gameCount == 0) {
			out.print("<script>alert('이용 내역(게임 수)이 없어 정산할 수 없습니다.'); history.back();</script>");
			return;
		}

		try (Connection conn = DBUtil.getConnection()) {

			// 수동 커밋 제어로 완전 전환하여 원자성 확보
			conn.setAutoCommit(false);
			MemberDAO memberDao = new MemberDAO();

			// 1 단계: BILLING 테이블에 정산 내역 등록
			int insertResult = memberDao.insertBilling(conn, bowlerId, grade, gameCount);

			if (insertResult > 0) {
				// 2 단계: BOWLER 테이블에서 회원의 상태값을 퇴실('N')로 변경 (무결성 유지 상태)
				int deleteResult = memberDao.deleteMember(conn, bowlerId);

				if (deleteResult > 0) {
					// 양쪽 작업이 완벽할 때만 최종 오라클 디스크에 저장(Commit)
					conn.commit();

					int fee = "VIP".equals(grade) ? 4000 : 5000;
					int total = gameCount * fee;
					out.print("<script>alert('[" + bowlerId + "번 회원] 총 " + total
							+ "원 결제가 완료되었습니다. 퇴실 처리합니다.'); location.href='" + request.getContextPath()
							+ "/mvc/member/list';</script>");
				} else {
					conn.rollback();
					out.print("<script>alert('퇴실 상태 변경에 실패하여 결제가 취소되었습니다.'); history.back();</script>");
				}
			} else {
				conn.rollback();
				out.print("<script>alert('정산 기록 등록에 실패했습니다.'); history.back();</script>");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			out.print("<script>alert('데이터베이스 처리 중 치명적인 오류가 발생했습니다.'); history.back();</script>");
		}
	}
}
