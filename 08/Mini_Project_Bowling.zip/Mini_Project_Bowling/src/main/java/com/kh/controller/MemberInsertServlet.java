package com.kh.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.kh.mvc.util.DBUtil;
import com.kh.mvc.model.MemberDAO;
import com.kh.mvc.model.MemberDTO;

@WebServlet("/mvc/member/insert")
public class MemberInsertServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // GET 요청 시 입력 페이지(JSP) 포워딩
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/member/insert.jsp").forward(request, response);
    }

    // POST 요청 시 데이터베이스 등록 처리 및 자동 자원 해제
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8"); // 한글 깨짐 방지 인코딩

        String name = request.getParameter("name");
        int laneNumber = Integer.parseInt(request.getParameter("laneNumber"));
        int gameCount = Integer.parseInt(request.getParameter("gameCount"));
        String grade = request.getParameter("grade");

        MemberDTO member = new MemberDTO(0, name, laneNumber, gameCount, grade);

        // [try-with-resources] Connection 자원이 블록 탈출 시 자동으로 close() 됩니다.
        try (Connection conn = DBUtil.getConnection()) {
            
            MemberDAO memberDao = new MemberDAO();
            int result = memberDao.insertMember(conn, member);
            
            if(result > 0) {
                // PRG 패턴: 중복 등록 방지를 위한 리다이렉트 처리
                response.sendRedirect(request.getContextPath() + "/mvc/member/list");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
