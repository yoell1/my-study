package com.kh.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.kh.mvc.util.DBUtil;
import com.kh.mvc.model.MemberDAO;

@WebServlet("/mvc/member/delete")
public class MemberDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int bowlerId = Integer.parseInt(request.getParameter("bowlerId"));

		try (Connection conn = DBUtil.getConnection()) {
			MemberDAO memberDao = new MemberDAO();
			int result = memberDao.deleteMember(conn, bowlerId);

			if (result > 0) {
				response.sendRedirect(request.getContextPath() + "/mvc/member/list");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
