package com.kh.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.kh.mvc.util.DBUtil;
import com.kh.mvc.model.MemberDAO;
import com.kh.mvc.model.MemberDTO;

@WebServlet("/mvc/member/list")
public class MemberListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// GET 요청 시 전체 회원 조회 및 자동 자원 해제
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// [try-with-resources] 리스트 조회 후 데이터베이스 커넥션이 완전 자동으로 닫힙니다.
		try (Connection conn = DBUtil.getConnection()) {

			MemberDAO memberDao = new MemberDAO();
			ArrayList<MemberDTO> list = memberDao.selectAllMembers(conn);

			// 수집한 데이터를 request Scope에 세팅하여 JSP로 포워딩
			request.setAttribute("memberList", list);
			request.getRequestDispatcher("/WEB-INF/views/member/list.jsp").forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
