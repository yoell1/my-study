package com.kh.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.kh.mvc.util.DBUtil;
import com.kh.mvc.model.MemberDAO;

@WebServlet("/mvc/member/sales")
public class SalesReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try (Connection conn = DBUtil.getConnection()) {
			MemberDAO memberDao = new MemberDAO();

			// 1. 총 통계 데이터 조회
			int[] summary = memberDao.selectSalesSummary(conn);
			// 2. 상세 결제 리스트 조회
			ArrayList<HashMap<String, Object>> billingList = memberDao.selectBillingList(conn);

			// 데이터 바인딩
			request.setAttribute("summary", summary);
			request.setAttribute("billingList", billingList);

			// sales.jsp로 화면 전환
			request.getRequestDispatcher("/WEB-INF/views/member/sales.jsp").forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
