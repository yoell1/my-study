package P;

import P.PianoPiece;

public class Run {

	public static void main(String[] args) {
		    
		PianoPiece p1 = new PianoPiece("용기", "체르니", "Etude Op.692 No. 21");
	        
		PianoPiece p2 = new PianoPiece("대양의 파도", "체르니", "Etude Op.692 No. 20");

	        // 2. 쇼팽
	        
		PianoPiece p3 = new PianoPiece("겨울바람", "쇼팽", "Etude Op.25 No.11");
	        
		PianoPiece p4 = new PianoPiece("추격", "쇼팽", "Etude Op.10 No.4");

	        // 3. 리스트
	        
		PianoPiece p5 = new PianoPiece("로켓", "리스트", "Etudes, S. 139: No. 2");
	        
		PianoPiece p6 = new PianoPiece("회상", "리스트", "Etudes, S. 139: No. 9");

	        // 4. 라흐마니노프
	        
		PianoPiece p7 = new PianoPiece("모스크바의 종", "라흐마니노프", "Op. 3, No. 2 (Prelude in C-sharp minor)");
	        
		PianoPiece p8 = new PianoPiece("레드 라이딩 후드", "라흐마니노프", "Op. 39, No. 6 (Etude-Tableaux)");

	        // 5. 모든 곡 정보 출력
	        System.out.println("==== 피아노 곡 목록 ====");
	        p1.inform();
	        p2.inform();
	        p3.inform();
	        p4.inform();
	        p5.inform();
	        p6.inform();
	        p7.inform();
	        p8.inform();
	    }

}
