package P;

public class PianoPiece {
	
	private String title;      
    private String composer;   
    private String op;       
    
    public PianoPiece(String title, String composer, String op) {
        this.title = title;
        this.composer = composer;
        this.op = op;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getComposer() {
        return composer;
    }

    public void setComposer(String composer) {
        this.composer = composer;
    }

    public String getOpus() {
        return op;
    }

    public void setOpus(String opus) {
        this.op = opus;
    }

    // 곡 정보를 출력하는 메서드
    public void inform() {
        System.out.printf("곡명: %s | 작곡가: %s | 작품번호: %s\n", 
                          this.title, this.composer, this.op);
    }
}